
package com.mycompany.guia8_ejercicio3;

import Servicios.Metodos;

public class Guia8_Ejercicio3 {

    public static void main(String[] args) {
  
    Metodos resultados = new Metodos();
    
    resultados.crearOperacion();
    
        System.out.println(resultados.sumar());
    
    
    
    
    }
    
}
