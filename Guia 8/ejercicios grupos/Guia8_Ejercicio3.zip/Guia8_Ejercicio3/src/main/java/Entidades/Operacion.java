
package Entidades;

public class Operacion {
    
    private int Num1;
    private int Num2;

    
    //constructores
    public Operacion() {
    }
    
    public Operacion(int num1, int num2) {
        this.Num1 = num1;
        this.Num2 = num2;
    }
    
    // get y set de los atributos 
    public int getNum1() {
        return Num1;
    }

    public void setNum1(int num1) {
        this.Num1 = num1;
    }

    public int getNum2() {
        return Num2;
    }

    public void setNum2(int num2) {
        this.Num2 = num2;
    }
    
    
    
    
    
    
}
