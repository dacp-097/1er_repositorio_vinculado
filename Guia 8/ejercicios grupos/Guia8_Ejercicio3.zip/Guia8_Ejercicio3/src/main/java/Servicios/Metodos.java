package Servicios;

import Entidades.Operacion;
import java.util.Scanner;

public class Metodos {
 
    Operacion calculos = new Operacion();
    Scanner read = new Scanner(System.in);
   
   public Operacion crearOperacion() {

        System.out.println("Ingrese el  valor de numero 1");
        calculos.setNum1(read.nextInt());

        System.out.println("Ingrese el  valor de numero 2");
        calculos.setNum2(read.nextInt());
 
        return calculos;
    }

      public int sumar() {

        int suma = calculos.getNum1() + calculos.getNum2();

        return suma;
    }

}
