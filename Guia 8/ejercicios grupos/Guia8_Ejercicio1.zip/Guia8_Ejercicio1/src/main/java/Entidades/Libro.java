package Entidades;

public class Libro {

    private int ISBN;
    private int numPaginas;
    private String autor;
    private String titulo;

    public Libro() {

    }

    public Libro(int ISBN, int numPaginas, String autor, String titulo) {
        this.ISBN = ISBN;
        this.numPaginas = numPaginas;
        this.autor = autor;
        this.titulo = titulo;
    }

    public int getISBN() {
        return ISBN;
    }

    public void setISBN(int ISBN) {
        this.ISBN = ISBN;
    }

    public int getNumPaginas() {
        return numPaginas;
    }

    public void setNumPaginas(int numPaginas) {
        this.numPaginas = numPaginas;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }



}
