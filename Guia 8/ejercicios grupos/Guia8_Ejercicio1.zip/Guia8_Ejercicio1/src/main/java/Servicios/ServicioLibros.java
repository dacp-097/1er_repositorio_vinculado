package Servicios;

import Entidades.Libro;
import java.util.Scanner;

public class ServicioLibros {

    public Libro cargarLibro() {

        Libro lb1 = new Libro();

        Scanner read = new Scanner(System.in).useDelimiter("\n");

        System.out.println("Ingrese el ISBN del libro");
        lb1.setISBN(read.nextInt());

        System.out.println("Ingrese el numero de paginas del libro");
        lb1.setNumPaginas(read.nextInt());

        System.out.println("Ingrese el Autor del libro");
        lb1.setAutor(read.next());

        System.out.println("Ingrese el Titulo del libro ");
        lb1.setTitulo(read.next());

        return lb1;
    }

    public void mostrarLibro(Libro lb1) {

        System.out.println("El autor del libro es: " + lb1.getTitulo());
        System.out.println("El nombre del libro es: " + lb1.getTitulo());
        System.out.println("El libro tiene " + lb1.getNumPaginas() + " Pag");
        System.out.println("ISBN del libro: " + lb1.getISBN());
    }

}
