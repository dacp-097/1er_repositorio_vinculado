package com.mycompany.guia8_ejercicio1;

import Entidades.Libro;
import Servicios.ServicioLibros;

public class Guia8_Ejercicio1 {

    public static void main(String[] args) {

        ServicioLibros sv = new ServicioLibros();

        Libro lb1 = sv.cargarLibro();      
        sv.mostrarLibro(lb1);
        
    }
}
