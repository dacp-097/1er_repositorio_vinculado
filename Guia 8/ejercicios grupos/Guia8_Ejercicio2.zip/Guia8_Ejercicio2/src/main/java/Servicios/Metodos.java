
package Servicios;

import Entidades.Circunferencia;
import java.util.Scanner;


public class Metodos {
    
    public Circunferencia crearCircunferencia(){
    
        Scanner read = new Scanner(System.in);
        
          Circunferencia circulo1 = new Circunferencia();
          
          System.out.println("Ingrese el radio del Circulo");
          circulo1.setRadio(read.nextDouble());
   
          circulo1.Area(circulo1.getRadio());
          
          circulo1.Perimetro(circulo1.getRadio());
          
    return circulo1;
    }
    
    public void mostrarCircunferencia(Circunferencia circulo1) {

        System.out.println("El area es:  " + Math.round(circulo1.getArea() * 100d) / 100d);
        System.out.println("El perimetro es:  " + Math.round(circulo1.getPerimetro() * 100d) / 100d);
    }


    
}
