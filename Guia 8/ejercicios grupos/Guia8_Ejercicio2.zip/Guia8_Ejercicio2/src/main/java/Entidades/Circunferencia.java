package Entidades;

public class Circunferencia {

    private double radio;
    private double area;
    private double perimetro;

    // constructores vacio
    public Circunferencia() {
    }
    ///constructor por parametros

    public Circunferencia(double radio) {
        this.radio = radio;
    }

    // geters
    public double getRadio() {
        return radio;
    }

    public double getArea() {
        return area;
    }

    public double getPerimetro() {
        return perimetro;
    }

    // seters
    public void setArea(double area) {
        this.area = area;
    }

    public void setPerimetro(double perimetro) {
        this.perimetro = perimetro;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }

    // formulas
    public double Area(Double radio) {

        area = (Math.PI) * Math.pow(radio, radio);

        return area;
    }

    public double Perimetro(Double radio) {

        perimetro = 2 * (Math.PI) * radio;

        return perimetro;
    }

}
