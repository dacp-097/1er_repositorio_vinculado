package com.mycompany.guia8_ejercicio2;

import Entidades.Circunferencia;
import Servicios.Metodos;

public class Guia8_Ejercicio2 {

    public static void main(String[] args) {

        Metodos mostrar = new Metodos();

        Circunferencia cir1 = mostrar.crearCircunferencia();
        mostrar.mostrarCircunferencia(cir1);

    }
}
